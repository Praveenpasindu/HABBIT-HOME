package com.example.habitnest.ui.fragments

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.habitnest.R
import com.example.habitnest.data.models.Habit
import com.example.habitnest.data.models.HabitProgress
import com.example.habitnest.data.repository.SharedPreferencesManager
import com.example.habitnest.ui.adapters.HabitsAdapter
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.chip.ChipGroup
import com.google.android.material.chip.Chip
import com.google.android.material.imageview.ShapeableImageView
import java.text.SimpleDateFormat
import java.util.*

/**
 * Fragment for displaying and managing daily habits
 */
class HabitsFragment : Fragment() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var fabAddHabit: ExtendedFloatingActionButton
    private lateinit var layoutEmptyState: View
    private lateinit var tvHabitCount: TextView
    private lateinit var tvGreeting: TextView
    private lateinit var tvDate: TextView
    private lateinit var dateContainer: LinearLayout
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var habitsAdapter: HabitsAdapter
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val displayDateFormat = SimpleDateFormat("EEEE, dd MMMM, yyyy", Locale.getDefault())
    private val dayOfWeekFormat = SimpleDateFormat("EEE", Locale.getDefault())
    private val dayOfMonthFormat = SimpleDateFormat("dd", Locale.getDefault())
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_habits, container, false)
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize components
        initializeViews(view)
        setupRecyclerView()
        setupClickListeners()
        setupGreeting()
        updateCurrentDate()
        loadUserProfile()
        loadHabits()
        updateMetrics()
        populateDateSelector()
    }
    
    private fun initializeViews(view: View) {
        prefsManager = SharedPreferencesManager.getInstance(requireContext())
        recyclerView = view.findViewById(R.id.recycler_habits)
        fabAddHabit = view.findViewById(R.id.fab_add_habit)
        layoutEmptyState = view.findViewById(R.id.layout_empty_state)
        tvHabitCount = view.findViewById(R.id.tv_habit_count)
        tvGreeting = view.findViewById(R.id.tv_greeting)
        tvDate = view.findViewById(R.id.tv_date)
        dateContainer = view.findViewById(R.id.dateContainer)
    }

    private fun setupGreeting() {
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greeting = when {
            currentHour < 12 -> "Morning"
            currentHour < 17 -> "Afternoon"
            else -> "Evening"
        }
        
        // Get user's name from SharedPreferences or default to "Friend"
        val userName = prefsManager.getUserName() ?: "Friend"
        tvGreeting.text = "$greeting, $userName 👋"
    }

    private fun updateCurrentDate() {
        val currentDate = Date()
        tvDate.text = displayDateFormat.format(currentDate)
    }

    override fun onResume() {
        super.onResume()
        // Refresh data when fragment becomes visible
        loadHabits()
        updateMetrics()
        setupGreeting()
        updateCurrentDate()
        loadUserProfile()
        populateDateSelector()
    }
    
    private fun populateDateSelector() {
        dateContainer.removeAllViews()
        
        val calendar = Calendar.getInstance()
        val today = calendar.timeInMillis
        
        // Show 14 days (7 previous days, today, and 6 next days)
        for (i in -7..6) {
            calendar.timeInMillis = today
            calendar.add(Calendar.DAY_OF_YEAR, i)
            
            val dateView = createDayView(calendar.time)
            dateContainer.addView(dateView)
        }
    }
    
    private fun createDayView(date: Date): View {
        val view = LayoutInflater.from(requireContext()).inflate(R.layout.item_date_selector, null)
        
        val dayOfWeekText = view.findViewById<TextView>(R.id.tv_day_of_week)
        val dayOfMonthText = view.findViewById<TextView>(R.id.tv_day_of_month)
        
        dayOfWeekText.text = dayOfWeekFormat.format(date)
        dayOfMonthText.text = dayOfMonthFormat.format(date)
        
        // Highlight today
        val isToday = isSameDay(date, Date())
        if (isToday) {
            dayOfMonthText.setBackgroundResource(R.drawable.bg_date_selected)
        } else {
            dayOfMonthText.setBackgroundResource(R.drawable.bg_date_unselected)
        }
        
        // Set click listener
        view.setOnClickListener {
            // Handle date selection
            loadHabitsForDate(dateFormat.format(date))
            
            // Update UI to show selected date
            populateDateSelector() // Refresh to show new selection
        }
        
        return view
    }
    
    private fun isSameDay(date1: Date, date2: Date): Boolean {
        val cal1 = Calendar.getInstance()
        val cal2 = Calendar.getInstance()
        cal1.time = date1
        cal2.time = date2
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
    }
    
    private fun loadHabitsForDate(date: String) {
        // For now, reuse current list and update metrics. Hook here for date-specific data if needed.
        loadHabits()
        updateMetrics()
    }

    private fun updateMetrics() {
        // Get views
        val tvCalories = view?.findViewById<TextView>(R.id.tv_calories)
        val tvHeartRate = view?.findViewById<TextView>(R.id.tv_heart_rate)
        val tvWeight = view?.findViewById<TextView>(R.id.tv_weight)
        val tvSteps = view?.findViewById<TextView>(R.id.tv_steps)
        
        // Get metrics from SharedPreferences
        val metrics = prefsManager.getUserMetrics()
        
        // Update UI with metrics
        tvCalories?.text = String.format("%.2f", metrics.calories)
        tvHeartRate?.text = metrics.heartRate.toString()
        tvWeight?.text = String.format("%.1f", metrics.weight)
        tvSteps?.text = String.format("%,d", metrics.steps)
    }
    
    private fun loadUserProfile() {
        // Get profile image path
        val profilePicPath = prefsManager.getUserProfilePicPath()
        val ivProfile = view?.findViewById<ShapeableImageView>(R.id.iv_profile)
        
        // Load profile image if exists, otherwise use default
        if (profilePicPath != null) {
            val uri = android.net.Uri.parse(profilePicPath)
            val resolver = requireContext().contentResolver
            val hasPermission = resolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }
            if (hasPermission) {
                try {
                    ivProfile?.setImageURI(uri)
                } catch (_: Exception) {
                    ivProfile?.setImageResource(R.drawable.avatar)
                }
            } else {
                // Permission likely lost (e.g., Photo Picker ephemeral URI) – fall back
                ivProfile?.setImageResource(R.drawable.avatar)
            }
        } else {
            ivProfile?.setImageResource(R.drawable.avatar)
        }
        
        // Set click listener for profile image
        ivProfile?.setOnClickListener {
            showProfileImagePicker()
        }
    }
    
    private fun showProfileImagePicker() {
        // Use ACTION_OPEN_DOCUMENT so we can take persistable read permission to the image
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    // Persist read permission for long-term access
                    requireContext().contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: SecurityException) { /* ignore if not supported */ }

                // Save the image URI
                prefsManager.setUserProfilePicPath(uri.toString())
                // Update the profile image
                try {
                    view?.findViewById<ShapeableImageView>(R.id.iv_profile)?.setImageURI(uri)
                } catch (_: Exception) { /* ignore display errors */ }
            }
        }
    }
    
    companion object {
        private const val PICK_IMAGE_REQUEST = 1
    }

    private fun setupRecyclerView() {
        habitsAdapter = HabitsAdapter(
            onHabitClick = { habit -> editHabit(habit) },
            onProgressClick = { habit, progress -> toggleHabitProgress(habit, progress) },
            onDeleteClick = { habit -> deleteHabit(habit) },
            onShareClick = { habit -> shareHabitProgress(habit) }
        )
        
        // Use different layout managers based on screen size
        val layoutManager = if (isTablet()) {
            androidx.recyclerview.widget.GridLayoutManager(context, 2)
        } else {
            LinearLayoutManager(context)
        }
        
        recyclerView.apply {
            this.layoutManager = layoutManager
            adapter = habitsAdapter
            setHasFixedSize(true)
        }
    }
    
    private fun setupClickListeners() {
        fabAddHabit.setOnClickListener {
            addNewHabit()
        }
    }
    
    private fun loadHabits() {
        val habits = prefsManager.getHabits()
        val today = dateFormat.format(Date())
        
        // Update habit count
        tvHabitCount.text = "${habits.size} ${if (habits.size == 1) "habit" else "habits"}"
        
        if (habits.isEmpty()) {
            // Show empty state
            recyclerView.visibility = View.GONE
            layoutEmptyState.visibility = View.VISIBLE
            
            // Update widget-style progress display
            updateWidgetProgress(0, 0, 0)
            return
        }
        
        // Hide empty state
        recyclerView.visibility = View.VISIBLE
        layoutEmptyState.visibility = View.GONE
        
        // Get today's progress for each habit
        val habitsWithProgress = habits.map { habit ->
            val progress = prefsManager.getHabitProgressForDay(habit.id, today)
                ?: HabitProgress(habit.id, today)
            Pair(habit, progress)
        }
        
        // Update progress summary
        val completedCount = habitsWithProgress.count { it.second.isCompleted }
        val totalCount = habits.size
        val progressPercentage = if (totalCount > 0) {
            ((completedCount.toFloat() / totalCount.toFloat()) * 100).toInt()
        } else {
            0
        }
        
        // Update widget-style progress display
        updateWidgetProgress(completedCount, totalCount, progressPercentage)
        
        habitsAdapter.updateHabits(habitsWithProgress)
    }
    
    private fun updateWidgetProgress(completedCount: Int, totalCount: Int, percentage: Int) {
        val widgetTitle = view?.findViewById<TextView>(R.id.widget_title)
        val widgetPercentage = view?.findViewById<TextView>(R.id.widget_progress_percentage)
        val widgetText = view?.findViewById<TextView>(R.id.widget_progress_text)
        
        widgetTitle?.text = getString(R.string.widget_title)
        widgetPercentage?.text = "$percentage%"
        widgetText?.text = getString(R.string.widget_habits_completed, completedCount, totalCount)
        
        // Update chart bars with actual habit history data
        updateChartBars()
    }
    
    private fun updateChartBars() {
        val barIds = arrayOf(
            R.id.bar_0, R.id.bar_1, R.id.bar_2, R.id.bar_3, 
            R.id.bar_4, R.id.bar_5, R.id.bar_6
        )
        
        // Get habits to calculate completion rates for the past 7 days
        val habits = prefsManager.getHabits()
        val calendar = Calendar.getInstance()
        
        // Calculate completion percentage for each of the last 7 days
        val completionPercentages = IntArray(7)
        
        for (i in 0..6) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            val date = dateFormat.format(calendar.time)
            
            if (habits.isEmpty()) {
                completionPercentages[6 - i] = 0
                continue
            }
            
            val completedHabits = habits.count { habit ->
                val progress = prefsManager.getHabitProgressForDay(habit.id, date)
                progress?.isCompleted ?: false
            }
            
            val percentage = if (habits.isNotEmpty()) {
                (completedHabits.toFloat() / habits.size.toFloat() * 100).toInt()
            } else {
                0
            }
            
            completionPercentages[6 - i] = percentage
        }
        
        // Update the bars with the calculated percentages
        for (i in barIds.indices) {
            val bar = view?.findViewById<View>(barIds[i])
            if (bar != null) {
                val percentage = completionPercentages[i]
                val layoutParams = bar.layoutParams
                // Set height based on percentage (max height is 60dp)
                layoutParams.height = (percentage * 60 / 100).dpToPx()
                bar.layoutParams = layoutParams
                
                // Set color based on completion rate
                val colorRes = if (percentage > 60) R.color.primary else R.color.progress_incomplete
                bar.setBackgroundResource(colorRes)
            }
        }
    }
    
    // Helper extension function to convert dp to pixels
    private fun Int.dpToPx(): Int {
        return (this * resources.displayMetrics.density).toInt()
    }
    
    private fun addNewHabit() {
        showAddHabitDialog()
    }
    
    private fun editHabit(habit: Habit) {
        showEditHabitDialog(habit)
    }
    
    private fun toggleHabitProgress(habit: Habit, currentProgress: HabitProgress) {
        val today = dateFormat.format(Date())
        val newProgress = if (currentProgress.isCompleted) {
            // Mark as incomplete
            currentProgress.copy(
                isCompleted = false,
                currentValue = 0,
                completionTime = null
            )
        } else {
            // Mark as complete
            currentProgress.copy(
                isCompleted = true,
                currentValue = habit.targetValue,
                completionTime = Date()
            )
        }
        
        prefsManager.saveHabitProgressForDay(habit.id, today, newProgress)
        loadHabits() // Refresh the list
    }
    
    private fun deleteHabit(habit: Habit) {
        // Show confirmation dialog
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.delete_habit))
            .setMessage("Are you sure you want to delete \"${habit.name}\"?")
            .setPositiveButton(getString(R.string.delete)) { _, _ ->
                prefsManager.deleteHabit(habit.id)
                loadHabits()
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    private fun shareHabitProgress(habit: Habit) {
        val today = dateFormat.format(Date())
        val progress = prefsManager.getHabitProgressForDay(habit.id, today)
        val progressText = if (progress?.isCompleted == true) {
            "Completed: ${habit.name}"
        } else {
            "Working on: ${habit.name}"
        }
        
        val shareText = getString(R.string.share_habit_progress, progressText)
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        
        startActivity(Intent.createChooser(shareIntent, getString(R.string.share_via)))
    }
    
    private fun setupUnitSelector(dialogView: View, spinnerUnit: AutoCompleteTextView, chipGroup: ChipGroup) {
        // Set up chip group click listeners
        for (i in 0 until chipGroup.childCount) {
            val chip = chipGroup.getChildAt(i) as Chip
            chip.setOnClickListener {
                spinnerUnit.setText(chip.text.toString(), false)
                chipGroup.visibility = View.GONE
            }
        }
        
        // Set up spinner click to show chips
        spinnerUnit.setOnClickListener {
            chipGroup.visibility = if (chipGroup.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }
    
    private fun showAddHabitDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_add_habit, null)
        
        val etHabitName = dialogView.findViewById<TextInputEditText>(R.id.et_habit_name)
        val etHabitDescription = dialogView.findViewById<TextInputEditText>(R.id.et_habit_description)
        val etTargetValue = dialogView.findViewById<TextInputEditText>(R.id.et_target_value)
        val spinnerUnit = dialogView.findViewById<AutoCompleteTextView>(R.id.spinner_unit)
        val chipGroup = dialogView.findViewById<ChipGroup>(R.id.chip_group_units)
        
        // Setup unit selector
        val units = arrayOf("times", "minutes", "hours", "glasses", "pages", "km")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, units)
        spinnerUnit.setAdapter(adapter)
        spinnerUnit.setText("times", false)
        
        // Setup unit selector with chips
        setupUnitSelector(dialogView, spinnerUnit, chipGroup)
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.add_habit))
            .setView(dialogView)
            .setPositiveButton(getString(R.string.save)) { _, _ ->
                val name = etHabitName.text?.toString()?.trim()
                val description = etHabitDescription.text?.toString()?.trim() ?: ""
                val targetText = etTargetValue.text?.toString()?.trim()
                val unit = spinnerUnit.text?.toString() ?: "times"
                
                if (!name.isNullOrBlank() && !targetText.isNullOrBlank()) {
                    try {
                        val target = targetText.toInt()
                        if (target > 0) {
                            val habit = Habit(
                                name = name,
                                description = description,
                                targetValue = target,
                                unit = unit
                            )
                            prefsManager.saveHabit(habit)
                            loadHabits()
                            
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Habit added successfully!",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Target value must be greater than 0",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: NumberFormatException) {
                        android.widget.Toast.makeText(
                            requireContext(),
                            "Please enter a valid target number",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "Please fill in all required fields",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    private fun showEditHabitDialog(habit: Habit) {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_add_habit, null)
        
        val etHabitName = dialogView.findViewById<TextInputEditText>(R.id.et_habit_name)
        val etHabitDescription = dialogView.findViewById<TextInputEditText>(R.id.et_habit_description)
        val etTargetValue = dialogView.findViewById<TextInputEditText>(R.id.et_target_value)
        val spinnerUnit = dialogView.findViewById<AutoCompleteTextView>(R.id.spinner_unit)
        val chipGroup = dialogView.findViewById<ChipGroup>(R.id.chip_group_units)
        
        // Pre-fill with current values
        etHabitName.setText(habit.name)
        etHabitDescription.setText(habit.description)
        etTargetValue.setText(habit.targetValue.toString())
        
        // Setup unit selector
        val units = arrayOf("times", "minutes", "hours", "glasses", "pages", "km")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, units)
        spinnerUnit.setAdapter(adapter)
        spinnerUnit.setText(habit.unit, false)
        
        // Setup unit selector with chips
        setupUnitSelector(dialogView, spinnerUnit, chipGroup)
        
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(getString(R.string.edit_habit))
            .setView(dialogView)
            .setPositiveButton(getString(R.string.save)) { _, _ ->
                val name = etHabitName.text?.toString()?.trim()
                val description = etHabitDescription.text?.toString()?.trim() ?: ""
                val targetText = etTargetValue.text?.toString()?.trim()
                val unit = spinnerUnit.text?.toString() ?: "times"
                
                if (!name.isNullOrBlank() && !targetText.isNullOrBlank()) {
                    try {
                        val target = targetText.toInt()
                        if (target > 0) {
                            val updatedHabit = habit.copy(
                                name = name,
                                description = description,
                                targetValue = target,
                                unit = unit
                            )
                            prefsManager.saveHabit(updatedHabit)
                            loadHabits()
                            
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Habit updated successfully!",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            android.widget.Toast.makeText(
                                requireContext(),
                                "Target value must be greater than 0",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()
                        }
                    } catch (e: NumberFormatException) {
                        android.widget.Toast.makeText(
                            requireContext(),
                            "Please enter a valid target number",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    android.widget.Toast.makeText(
                        requireContext(),
                        "Please fill in all required fields",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }
    
    private fun isTablet(): Boolean {
        val configuration = resources.configuration
        return configuration.screenLayout and android.content.res.Configuration.SCREENLAYOUT_SIZE_MASK >= android.content.res.Configuration.SCREENLAYOUT_SIZE_LARGE
    }
}