package com.example.habitnest.ui.charts

import android.content.Context
import com.example.habitnest.R
import com.example.habitnest.data.models.MoodEntry
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.MarkerView
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.utils.MPPointF
import java.text.SimpleDateFormat
import java.util.*

/**
 * Helper class for creating mood trend charts
 */
class MoodChartHelper(private val context: Context) {
    
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
    
    fun setupMoodTrendChart(chart: LineChart, moodEntries: List<MoodEntry>) {
        chart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            setDragEnabled(true)
            setScaleEnabled(true)
            setPinchZoom(true)
            setDoubleTapToZoomEnabled(false)
            setBackgroundColor(context.getColor(R.color.surface))
            
            // Modern chart styling
            setDrawGridBackground(true)
            setGridBackgroundColor(context.getColor(R.color.surface_variant))
            setDrawBorders(false)
            setNoDataText("No mood data available")
            setNoDataTextColor(context.getColor(R.color.text_secondary))
            
            // Add padding for better visual appeal
            setExtraOffsets(16f, 20f, 16f, 20f)
            
            // Configure X-axis with modern styling
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(true)
                gridColor = context.getColor(R.color.divider_color)
                gridLineWidth = 1f
                enableGridDashedLine(10f, 5f, 0f)
                granularity = 1f
                labelCount = 7
                textColor = context.getColor(R.color.text_primary)
                textSize = 12f
                setDrawAxisLine(false)
                yOffset = 10f
                setAvoidFirstLastClipping(true)
            }
            
            // Configure Y-axis with modern styling and mood labels
            axisLeft.apply {
                axisMinimum = -2.5f
                axisMaximum = 2.5f
                setDrawGridLines(true)
                gridColor = context.getColor(R.color.divider_color)
                gridLineWidth = 1f
                enableGridDashedLine(10f, 5f, 0f)
                textColor = context.getColor(R.color.text_primary)
                textSize = 11f
                setDrawAxisLine(false)
                xOffset = 10f
                labelCount = 5
                setDrawZeroLine(true)
                zeroLineColor = context.getColor(R.color.primary)
                zeroLineWidth = 2f
                
                // Custom value formatter for mood labels
                valueFormatter = object : com.github.mikephil.charting.formatter.ValueFormatter() {
                    override fun getFormattedValue(value: Float): String {
                        return when {
                            value >= 2f -> "😄"
                            value >= 1f -> "😊"
                            value >= -1f -> "😐"
                            value >= -2f -> "😔"
                            else -> "😢"
                        }
                    }
                }
            }
            
            axisRight.isEnabled = false
            
            // Configure modern legend
            legend.apply {
                isEnabled = true
                textColor = context.getColor(R.color.text_primary)
                textSize = 12f
                form = com.github.mikephil.charting.components.Legend.LegendForm.CIRCLE
                formSize = 12f
                xEntrySpace = 8f
                yEntrySpace = 4f
                setDrawInside(false)
                verticalAlignment = com.github.mikephil.charting.components.Legend.LegendVerticalAlignment.TOP
                horizontalAlignment = com.github.mikephil.charting.components.Legend.LegendHorizontalAlignment.CENTER
                orientation = com.github.mikephil.charting.components.Legend.LegendOrientation.HORIZONTAL
                yOffset = 10f
            }
        }
        
        // Process mood data for the last 7 days with enhanced interpolation
        val chartData = getInterpolatedMoodData(moodEntries)
        
        if (chartData.isNotEmpty()) {
            val dataSet = LineDataSet(chartData, "📈 Mood Trend").apply {
                // Dynamic line color based on overall mood trend
                val avgMood = chartData.map { it.y }.average()
                color = when {
                    avgMood >= 1f -> context.getColor(R.color.success_green)
                    avgMood >= 0f -> context.getColor(R.color.primary)
                    avgMood >= -1f -> context.getColor(R.color.warning_orange) 
                    else -> context.getColor(R.color.error_red)
                }
                
                // Modern line styling
                lineWidth = 4f
                setDrawHorizontalHighlightIndicator(false)
                setDrawVerticalHighlightIndicator(true)
                highlightLineWidth = 2f
                highLightColor = context.getColor(R.color.primary)
                enableDashedHighlightLine(10f, 5f, 0f)
                
                // Enhanced circle styling
                setCircleColors(getCircleColorsForMoods(chartData))
                circleRadius = 8f
                circleHoleRadius = 4f
                setDrawCircleHole(true)
                circleHoleColor = context.getColor(R.color.surface)
                
                // Value styling
                valueTextSize = 10f
                valueTextColor = context.getColor(R.color.text_secondary)
                setDrawValues(false) // We'll use custom markers instead
                
                // Modern fill gradient
                setDrawFilled(true)
                fillFormatter = com.github.mikephil.charting.formatter.IFillFormatter { _, _ -> chart.axisLeft.axisMinimum }
                
                // Gradient fill drawable
                val drawable = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(
                        android.graphics.Color.argb(100, android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color)),
                        android.graphics.Color.argb(20, android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color))
                    )
                )
                fillDrawable = drawable
                
                // Smooth curve
                mode = LineDataSet.Mode.CUBIC_BEZIER
                cubicIntensity = 0.2f
            }
            
            val lineData = LineData(dataSet)
            chart.data = lineData
            
            // Set up X-axis labels
            val labels = getLast7DaysLabels()
            chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            
            // Add smooth animations
            chart.animateXY(1000, 1500, com.github.mikephil.charting.animation.Easing.EaseInOutQuart)
            
            // Custom marker for touch interactions
            val marker = createCustomMarker()
            chart.marker = marker
            
            chart.invalidate() // Refresh chart
        } else {
            chart.clear()
            chart.invalidate()
        }
    }
    
    private fun prepareMoodData(moodEntries: List<MoodEntry>): List<Entry> {
        val calendar = Calendar.getInstance()
        val entries = mutableListOf<Entry>()
        
        // Get mood data for the last 7 days
        for (i in 6 downTo 0) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            val dateString = dateFormat.format(calendar.time)
            
            // Find moods for this day
            val dayMoods = moodEntries.filter { it.date == dateString }
            
            if (dayMoods.isNotEmpty()) {
                // Calculate average mood for the day and center around 0
                // Convert 1-5 scale to -2 to +2 scale (0 in middle)
                val averageMood = dayMoods.map { it.mood.value }.average().toFloat()
                val centeredMood = averageMood - 3f  // Shift from 1-5 to -2 to +2
                entries.add(Entry((6 - i).toFloat(), centeredMood))
            } else {
                // No mood entry for this day
                entries.add(Entry((6 - i).toFloat(), 0f)) // 0 for no data
            }
        }
        
        return entries
    }
    
    private fun getLast7DaysLabels(): List<String> {
        val calendar = Calendar.getInstance()
        val labels = mutableListOf<String>()
        
        for (i in 6 downTo 0) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            labels.add(dayFormat.format(calendar.time))
        }
        
        return labels
    }
    
    /**
     * Get circle colors based on mood values for visual differentiation
     */
    private fun getCircleColorsForMoods(entries: List<Entry>): List<Int> {
        return entries.map { entry ->
            when {
                entry.y >= 2f -> context.getColor(R.color.mood_very_happy)
                entry.y >= 1f -> context.getColor(R.color.mood_happy)
                entry.y >= -1f -> context.getColor(R.color.mood_neutral)
                entry.y >= -2f -> context.getColor(R.color.mood_sad)
                else -> context.getColor(R.color.mood_very_sad)
            }
        }
    }
    
    /**
     * Create a custom marker for touch interactions
     */
    private fun createCustomMarker(): com.github.mikephil.charting.components.MarkerView {
        return object : com.github.mikephil.charting.components.MarkerView(context, R.layout.custom_marker_view) {
            
            override fun refreshContent(e: Entry?, highlight: com.github.mikephil.charting.highlight.Highlight?) {
                if (e != null) {
                    val moodText = when {
                        e.y >= 2f -> "Very Happy 😄"
                        e.y >= 1f -> "Happy 😊"
                        e.y >= -1f -> "Neutral 😐"
                        e.y >= -2f -> "Sad 😔"
                        else -> "Very Sad 😢"
                    }
                    
                    // Set marker content (you'll need to create the layout)
                    val tvContent = findViewById<android.widget.TextView>(R.id.tvContent)
                    tvContent?.text = moodText
                }
                super.refreshContent(e, highlight)
            }
            
            override fun getOffset(): MPPointF {
                return MPPointF(-(width / 2f), -height.toFloat())
            }
        }
    }
    
    /**
     * Enhanced mood data preparation with better interpolation
     */
    private fun getInterpolatedMoodData(moodEntries: List<MoodEntry>): List<Entry> {
        val calendar = Calendar.getInstance()
        val entries = mutableListOf<Entry>()
        
        // Get mood data for the last 7 days with smooth interpolation
        for (i in 6 downTo 0) {
            calendar.time = Date()
            calendar.add(Calendar.DAY_OF_YEAR, -i)
            val dateString = dateFormat.format(calendar.time)
            
            // Find moods for this day
            val dayMoods = moodEntries.filter { it.date == dateString }
            
            val moodValue = if (dayMoods.isNotEmpty()) {
                // Calculate weighted average based on time of entry
                val averageMood = dayMoods.map { it.mood.value }.average().toFloat()
                averageMood - 3f  // Center around 0
            } else {
                // Interpolate from neighboring days if no data
                val prevDay = moodEntries.filter { 
                    val entryDate = dateFormat.parse(it.date)
                    entryDate != null && entryDate.before(calendar.time)
                }.maxByOrNull { it.date }
                
                val nextDay = moodEntries.filter { 
                    val entryDate = dateFormat.parse(it.date)
                    entryDate != null && entryDate.after(calendar.time)
                }.minByOrNull { it.date }
                
                when {
                    prevDay != null && nextDay != null -> {
                        val prevMood = prevDay.mood.value - 3f
                        val nextMood = nextDay.mood.value - 3f
                        (prevMood + nextMood) / 2f
                    }
                    prevDay != null -> prevDay.mood.value - 3f
                    nextDay != null -> nextDay.mood.value - 3f
                    else -> 0f
                }
            }
            
            entries.add(Entry((6 - i).toFloat(), moodValue))
        }
        
        return entries
    }
    
    /**
     * Alternative setup for mood chart with area styling (alternative UI)
     */
    fun setupMoodAreaChart(chart: LineChart, moodEntries: List<MoodEntry>) {
        chart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            setDragEnabled(false)
            setScaleEnabled(false)
            setPinchZoom(false)
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            
            // Minimal styling for area chart
            setDrawGridBackground(false)
            setDrawBorders(false)
            setExtraOffsets(20f, 30f, 20f, 30f)
            
            // Simplified X-axis
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                setDrawAxisLine(false)
                granularity = 1f
                labelCount = 7
                textColor = context.getColor(R.color.text_secondary)
                textSize = 11f
                yOffset = 15f
            }
            
            // Simplified Y-axis
            axisLeft.apply {
                axisMinimum = -2.5f
                axisMaximum = 2.5f
                setDrawGridLines(false)
                setDrawAxisLine(false)
                setDrawLabels(false)
                setDrawZeroLine(true)
                zeroLineColor = context.getColor(R.color.text_secondary)
                zeroLineWidth = 1f
            }
            
            axisRight.isEnabled = false
            legend.isEnabled = false
        }
        
        val chartData = getInterpolatedMoodData(moodEntries)
        
        if (chartData.isNotEmpty()) {
            val dataSet = LineDataSet(chartData, "Mood Area").apply {
                // Area fill styling
                setDrawCircles(false)
                setDrawValues(false)
                lineWidth = 3f
                color = context.getColor(R.color.primary)
                
                // Full area fill
                setDrawFilled(true)
                fillAlpha = 120
                
                val gradientColors = intArrayOf(
                    android.graphics.Color.argb(150, 38, 201, 196), // primary with alpha
                    android.graphics.Color.argb(50, 38, 201, 196),
                    android.graphics.Color.argb(10, 38, 201, 196)
                )
                
                val drawable = android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    gradientColors
                )
                fillDrawable = drawable
                
                // Ultra smooth curve
                mode = LineDataSet.Mode.CUBIC_BEZIER
                cubicIntensity = 0.3f
            }
            
            val lineData = LineData(dataSet)
            chart.data = lineData
            
            val labels = getLast7DaysLabels()
            chart.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            
            // Gentle animation
            chart.animateY(2000, Easing.EaseOutCubic)
            chart.invalidate()
        } else {
            chart.clear()
            chart.invalidate()
        }
    }
}